 var savind=-1;
 timeID=null;
 imgsrc = new Array('http://www.shuku.net/image/img1.gif','http://www.shuku.net/image/img2.gif','http://www.shuku.net/image/img3.gif','http://www.shuku.net/image/img4.gif','http://www.shuku.net/image/img5.gif',
                    'http://www.shuku.net/image/img6.gif','http://www.shuku.net/image/img7.gif','http://www.shuku.net/image/img8.gif','http://www.shuku.net/image/img9.gif');
 thepage = new Array('http://www.yifannet.com/','http://www.gotofind.com/',
                    'http://www.yifannet.com:8080/News/','http://eo.yifan.net/index_c.html',
                    'http://www.yifanbbs.com/liao/chat1.html',
                    'http://www.yifanbbs.com/','http://www.yifannet.com/postcard/',
                    'http://www.sinc.sunysb.edu/Stu/yihe/novels/cnovel.html','http://www.yifan.net/');
 images = new Array(9);
for(var i = 0; i <= 8; i++) {
    images[i] = new Image();                 // Create an Image object
//    images[i].onload = count_images;         // assign the event handler
    images[i].src = imgsrc[i];  // tell it what URL to load
}
 
 function shdesc(ind) {
  if(ind == savind) return false;
  if(ind == 0) {
     xrand=Math.round(10*Math.random());
     ind = (xrand > 0)?xrand:1;
     if(ind > 9) ind=1;
  }

  document.imgdesc.src = images[ind-1].src;
  document.links[8].href = thepage[ind-1];
 if(timeID != null) clearTimeout(timeID);
 savind=ind;
 var indc=ind % 8 +1;
 timeID=setTimeout('shdesc('+ indc + ')',10000);
  return false;
}  
function initializeimg() {
var doc=document;
doc.write('<table align="center" border=0 cellpadding=0 cellspacing=1>');
doc.write('<tr><td><table border=1 bgcolor="#E0EFFF" cellpadding=4 cellspacing=0 BORDERCOLORlight="#3E6299" bordercolordark="ffffff"><tr><td class=p9>');
doc.write('<a href="http://www.yifannet.com" onMouseOver="javascript:shdesc(1);">�ෲ��ҳ</a></td></tr></table>');
doc.write('</td><td><table border=1 bgcolor="#E0EFFF" cellpadding=4 cellspacing=0 BORDERCOLORlight="#3E6299" bordercolordark="ffffff"><tr><td class=p9><a href="http://www.gotofind.com" onMouseOver="javascript:shdesc(2);">�ෲ����</a></td></tr></table>');
doc.write('</td><td><table border=1 bgcolor="#E0EFFF" cellpadding=4 cellspacing=0 BORDERCOLORlight="#3E6299" bordercolordark="ffffff"><tr><td class=p9><a href="http://www.yifannet.com:8080/News/" onMouseOver="javascript:shdesc(3);">��������</a></td></tr></table>');
doc.write('</td><td><table border=1 bgcolor="#E0EFFF" cellpadding=4 cellspacing=0 BORDERCOLORlight="#3E6299" bordercolordark="ffffff"><tr><td class=p9><a href="http://eo.yifan.net/index_c.html" onMouseOver="javascript:shdesc(4);">��������</a></td></tr></table>');
doc.write('</td><td><table border=1 bgcolor="#E0EFFF" cellpadding=4 cellspacing=0 BORDERCOLORlight="#3E6299" bordercolordark="ffffff"><tr><td class=p9><a href="http://www.yifanbbs.com/liao/chat1.html" onMouseOver="javascript:shdesc(5);">����㳡</a></td></tr></table>');
doc.write('</td><td><table border=1 bgcolor="#E0EFFF" cellpadding=4 cellspacing=0 BORDERCOLORlight="#3E6299" bordercolordark="ffffff"><tr><td class=p9><a href="http://www.yifanbbs.com/" onMouseOver="javascript:shdesc(6);">�ĺ���̸</a></td></tr></table>');
doc.write('</td><td><table border=1 bgcolor="#E0EFFF" cellpadding=4 cellspacing=0 BORDERCOLORlight="#3E6299" bordercolordark="ffffff"><tr><td class=p9><a href="http://www.yifannet.com/postcard/" onMouseOver="javascript:shdesc(7);">�ؿ����</a></td></tr></table>');
doc.write('</td><td><table border=1 bgcolor="#E0EFFF" cellpadding=4 cellspacing=0 BORDERCOLORlight="#3E6299" bordercolordark="ffffff"><tr><td class=p9><a href="http://www.sinc.sunysb.edu/Stu/yihe/novels/cnovel.html" onMouseOver="javascript:shdesc(8);">�ෲ���</a></td></tr></table>');
doc.write('</td></tr></table>');
doc.write('<center>');
doc.write('<a href="http://www.yifannet.com/" target="_blank"><img src="http://www.shuku.net/image/img1.gif" name="imgdesc" border=0></a><br>');
doc.write('</center>');
return false;
}
